# BlackBox.exe

## Setup

1. Run `npm install`
2. Run `npm run dev`

## Deploy to Vercel
1. Push to GitHub
2. Import to Vercel
3. Done!
